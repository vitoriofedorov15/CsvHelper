namespace ClassLibrary;

public class Address
{
    private string _address, _phone, _email, _website;
    public string AddressLocation
    {
        get { return _address;} set { _address = value; }
    }
    public string Phone {
        get { return _phone;} set { _phone = value; }
    }
    public string Email
    {
        get { return _email;} set { _email = value; }
    }
    public string Website
    {
        get { return _website;} set { _website = value; }
    }

    public Address(string address, string phone, string email, string website)
    {
        _phone = phone;
        _email = email;
        _website = website;
        _address = address;
    }

    public Address()
    {
        _phone = "";
        _email = "";
        _website = "";
        _address = "";
    }
}