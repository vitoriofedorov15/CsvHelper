using System.Text;

namespace ClassLibrary;
using System.IO;

public class Methods
{
    /// <summary>
    /// Повторяющаяся часть программы после выполнения команды пользователя.
    /// </summary>
    /// <param name="userCommand">Команда пользователя.</param>
    /// <param name="resultList">Список, в который сохраняются результаты команды.</param>
    public static void ProgramRepeating(ref int userCommand, ref List<Kindergarten> resultList)
    {
        if (userCommand != 1)
            SaveData(resultList);
        PrintMenu();
        while (!int.TryParse(Console.ReadLine(), out userCommand))
            Console.WriteLine("Введена некорректная команда. Повторите попытку.");
    }

    /// <summary>
    /// Завершает программу или продолжает её выполнение в зависимости от нажатой клавиши.
    /// </summary>
    /// <param name="endkey">Клавиша, которую ввел пользователь.</param>
    public static void ProgramEnding(ref ConsoleKey endkey)
    {
        Console.WriteLine(
            "Для завершения работы программы нажмите Tab. Для продолжения работы программы с новым файлом нажмите любую другую клавишу.");
        endkey = Console.ReadKey().Key;
        if (endkey == ConsoleKey.Tab)
        {
            Console.WriteLine("\nПрограмма будет завершена.");
        }
        else
        {
            Console.Clear();
        }
    }

    /// <summary>
    /// Фильтрует список детских садов по указанному параметру.
    /// </summary>
    /// <param name="parameter">Параметр, по которому будет производиться фильтрация.</param>
    /// <param name="kindergartens">Исходный список детских садов.</param>
    /// <param name="resultList">Список, в который сохраняются результаты фильтрации.</param>
    public static void CommandFilter(string parameter, ref List<Kindergarten> kindergartens, ref List<Kindergarten> resultList)
    {
        Console.WriteLine(
            $"Будет произведена фильтрация по значению {parameter}. Введите значение для фильтрации: ");
        string filtration = Console.ReadLine();
        if (parameter == "vid_uchrezhdenia")
        {
            resultList = kindergartens.Where(k => k.VidUchrezhdenia.Contains(filtration)).ToList();
        }
        else
        {
            resultList = kindergartens.Where(k => k.FormOfIncorporation.Contains(filtration)).ToList();
        }
    }

    /// <summary>
    /// Выполняет сортировку списка детских садов по значению rayon.
    /// </summary>
    /// <param name="resultList">Список, в который сохраняются результаты сортировки.</param>
    /// <param name="kindergartens">Исходный список детских садов.</param>
    public static void CommandSort(ref List<Kindergarten> resultList, ref List<Kindergarten> kindergartens)
    {
        Console.WriteLine("Будет выполнена сортировка по значению rayon. " +
                          "\nДля сортировки по возрастанию напишите \"up\", иначе напишите \"down\".");
        string s1 = Console.ReadLine();
        while (s1 != "up" && s1 != "down")
        {
            Console.WriteLine("Некорректное введённое значение. Введите снова: ");
            s1 = Console.ReadLine();
        }
        
        switch (s1)
        {
            case "down":
                resultList = kindergartens.OrderByDescending(k => k.Rayon).ToList();
                break;
            case "up":
                resultList = kindergartens.OrderBy(k => k.Rayon).ToList();
                break;
        }
    }

        /// <summary>
    /// Выводит на экран N первых или последних записей из списка детских садов в зависимости от выбора пользователя.
    /// </summary>
    /// <param name="kindergartens">Список детских садов.</param>
    public static void CommandPrintNLines(ref List<Kindergarten> kindergartens)
    {
        Console.WriteLine("Для просмотра будут предоставлены N первых/последних записей из файла." +
                          "\nВведите значение N: ");
        int n;
        while (!int.TryParse(Console.ReadLine(), out n) || n <= 1)
            Console.WriteLine("Неккоректное значение N. Введите N снова: ");
        Console.WriteLine(
            "Для вывода N первых записей напишите \"top\", иначе напишите \"bottom\".");
        string s = Console.ReadLine();
        while (s != "top" && s != "bottom")
        {
            Console.WriteLine("Неккоректное введённое значение. Введите снова: ");
            s = Console.ReadLine();
        }

        switch (s)
        {
            case "top":
                PrintNLines(Choice.Top, n, kindergartens);
                break;

            case "bottom":
                PrintNLines(Choice.Bottom, n, kindergartens);
                break;
        }
    }

    /// <summary>
    /// Проверяет структуру данных, считанных из файла, и выполняет чтение в список детских садов, если формат корректен.
    /// </summary>
    /// <param name="data">Массив строк, представляющих данные из файла.</param>
    /// <param name="kindergartens">Список детских садов.</param>
    public static void CheckDataStructure(ref string[] data, out List<Kindergarten> kindergartens)
    {
        if (CheckFileFormat(data) == true)
        {
            kindergartens = CsvProcessing.Read(data);
        }
        else
        {
            throw new Exception("Некорректная структура файла.");
        }
    }

    /// <summary>
    /// Инициализирует программу, считывает путь к файлу и данные из файла.
    /// </summary>
    /// <param name="path">Путь к файлу.</param>
    /// <param name="data">Массив строк, представляющих данные из файла.</param>
    public static void StartingReadPath(out string path, out string[] data)
    {
        Console.WriteLine("Вас приветствует программа.");
        path = ReadUserPath();
        try
        {
            data = File.ReadAllLines(path);
        }
        catch
        {
            throw new Exception("Считать строки файла не удалось.");
        }
    }

    /// <summary>
    /// Проверяет корректность ввода команды пользователя и предлагает ввести её заново при ошибке.
    /// </summary>
    /// <param name="userData">Команда пользователя.</param>
    public static void CheckInputCommand(out int userData)
    {
        while (!int.TryParse(Console.ReadLine(), out userData) || userData > 5 || userData < 1)
        {
            Console.WriteLine("Введена некорректная команда. Повторите попытку.");
        }
    }

    /// <summary>
    /// Выводит на экран меню программы с доступными командами.
    /// </summary>
    public static void PrintMenu()
    {
        Console.WriteLine("1. Посмотреть N первых или последних записей таблицы\n" +
                          "2. Выполнить сортировку по значению rayon\n" +
                          "3. Выполнить фильтрацию по значению vid_uchrezhdeniya\n" +
                          "4. Выполнить фильтрацию по значению form_of_incorporation\n" +
                          "5. Выйти из программы");
    }

    /// <summary>
    /// Считывает абсолютный путь к файлу с csv-данными от пользователя, проверяет его корректность и возвращает его.
    /// </summary>
    /// <returns>Абсолютный путь к файлу.</returns>
    public static string ReadUserPath()
    {
        Console.WriteLine("Введите абсолютный путь к файлу с csv-данными:");
        string path = Console.ReadLine();
        while (path == null || path == "" || !File.Exists(path))
        {
            if (File.Exists(path) == false && path != null && path != "")
                Console.WriteLine("Файл не найден, повторите попытку ввода:");
            else
                Console.WriteLine("Произошла ошибка, скорее всего, файла не существует. Повторите попытку ввода:");
            path = Console.ReadLine();
        }

        return path;
    }

    /// <summary>
    /// Проверяет формат данных в файле и возвращает результат проверки.
    /// </summary>
    /// <param name="data">Массив строк, представляющих данные из файла.</param>
    /// <returns>True, если формат корректен, иначе - false.</returns>
    public static bool CheckFileFormat(string[] data)
    {
        if (data.Length == 0)
        {
            return false;
        }
        
        if (data[0] != "ROWNUM;name;adress;okrug;rayon;form_of_incorporation;submission;tip_uchrezhdeniya;" +
            "vid_uchrezhdeniya;telephone;web_site;e_mail;X;Y;global_id;")
        {
            return false;
        }

        return true;
    }

        
    /// <summary>
    /// Перечисление для выбора вывода N первых или последних записей.
    /// </summary>
    public enum Choice
    {
        Top,
        Bottom
    }

    /// <summary>
    /// Выводит на экран N первых или последних записей из списка детских садов в зависимости от выбора пользователя.
    /// </summary>
    /// <param name="end">Выбор вывода верхних или нижних записей.</param>
    /// <param name="n">Количество записей для вывода.</param>
    /// <param name="kindergartens">Список детских садов.</param>
    public static void PrintNLines(Choice end, int n, List<Kindergarten> kindergartens)
    {
        switch (end)
        {
            case Choice.Top:
                if (n > kindergartens.Count)
                {
                    Console.WriteLine(
                        "ROWNUM | name | adress | okrug | rayon | form_of_incorporation | submission | tip_uchrezhdeniya | " +
                        "vid_uchrezhdeniya | telephone | web_site | e_mail | X | Y | global_id");
                    Console.WriteLine("Введённое значение N превысило количество строк в файле. Будут выведены все строки.");
                    foreach (Kindergarten kindergarten in kindergartens)
                    {
                        Console.WriteLine(kindergarten.TableOutput());
                    }
                }
                else
                {
                    Console.WriteLine(
                        "ROWNUM | name | adress | okrug | rayon | form_of_incorporation | submission | tip_uchrezhdeniya | " +
                        "vid_uchrezhdeniya | telephone | web_site | e_mail | X | Y | global_id");
                    for (int i = 0; i < n; i++)
                    {
                        Console.WriteLine(kindergartens[i].TableOutput());
                    }
                }
                break;

            case Choice.Bottom:
                if (n > kindergartens.Count)
                {
                    Console.WriteLine("Введённое значение N превысило количество строк в файле. Будут выведены все строки с конца.");
                    Console.WriteLine(
                        "ROWNUM | name | adress | okrug | rayon | form_of_incorporation | submission | tip_uchrezhdeniya | " +
                        "vid_uchrezhdeniya | telephone | web_site | e_mail | X | Y | global_id");
                    for (int i = kindergartens.Count - 1; i >= 0; i--)
                        Console.WriteLine(kindergartens[i].TableOutput());
                }
                else
                {
                    Console.WriteLine(
                        "ROWNUM | name | adress | okrug | rayon | form_of_incorporation | submission | tip_uchrezhdeniya | " +
                        "vid_uchrezhdeniya | telephone | web_site | e_mail | X | Y | global_id");
                    for (int i = kindergartens.Count - 1; i > kindergartens.Count - n - 1; i--)
                    {
                        Console.WriteLine(kindergartens[i].TableOutput());
                    }
                }
                break;
        }
    }

    /// <summary>
    /// Сохраняет данные в файл в зависимости от выбора пользователя.
    /// </summary>
    /// <param name="resultList">Список детских садов для сохранения.</param>
    public static void SaveData(List<Kindergarten> resultList)
    {
        Console.WriteLine("Выберите режим сохранения в файл\n" +
                          "1. Создать новый файл\n" +
                          "2. Заменить содержимое уже существующего файла\n" +
                          "3. Добавить сохраняемые данные к содержимому существующего файла");

        string regime = Console.ReadLine()!;
        while (regime != "1" && regime != "2" && regime != "3")
        {
            Console.WriteLine("Введён некорректный режим. Введите снова: ");
            regime = Console.ReadLine()!;
        }

        string[] res1 = new string[resultList.Count + 1];
        res1[0] =
            "ROWNUM;name;adress;okrug;rayon;form_of_incorporation;submission;tip_uchrezhdeniya;" +
            "vid_uchrezhdeniya;telephone;web_site;e_mail;X;Y;global_id;";
        for (int i = 1; i < resultList.Count; i++)
        {
            res1[i] = resultList[i].ToString();
        }
        bool isSaved = false;
        string path;
        switch (regime)
        {
            case "1":
                Console.WriteLine("Введите путь: ");
                path = Console.ReadLine() ?? "";
                while (!isSaved)
                {
                    try
                    {
                        if (File.Exists(path))
                        {
                            Console.WriteLine(
                                "Файл по введённому пути уже существует. Все имеющиеся в нём данные будут переписаны.");
                        }

                        using (StreamWriter sw = new StreamWriter(path))
                        {
                            foreach (string s in res1)
                            {
                                if (s != "" && s != null)
                                {
                                    sw.WriteLine(s);
                                }
                            }
                        }

                        isSaved = true;
                        Console.WriteLine("Сохранение прошло успешно.");
                    }
                    catch
                    {
                        Console.WriteLine("Произошла ошибка при создании файла. Введите новый путь: ");
                        path = Console.ReadLine() ?? "";
                    }
                }
                break;
            case "2":
                Console.WriteLine("Введите путь файла, содержание которого требуется изменить.");
                path = Console.ReadLine() ?? "";
                while (!isSaved)
                {
                    if (File.Exists(path))
                    {
                        try
                        {
                            using (StreamWriter sw = new StreamWriter(path, false, Encoding.UTF8))
                            {
                                foreach (string s in res1)
                                {
                                    if (s != "" && s != null)
                                    {
                                        sw.WriteLine(s);
                                    }
                                }
                            }

                            isSaved = true;
                            Console.WriteLine("Сохранение прошло успешно.");
                        }
                        catch
                        {
                            Console.WriteLine("Произошла ошибка при сохранении. Введите новый путь к файлу: ");
                            path = Console.ReadLine() ?? "";
                        }
                    }
                    else
                    {
                        Console.WriteLine("Файла по введённому пути не существует. Введите новый путь файла: ");
                        path = Console.ReadLine() ?? "";
                    }
                }
                break;
            case "3":
                Console.WriteLine("Введите путь файла, к содержанию которого требуется добавить строки: ");
                path = Console.ReadLine() ?? "";
                while (!isSaved)
                {
                    if (File.Exists(path))
                    {
                        try
                        {
                            string[] res2 = new string[resultList.Count];
                            for (int i = 0; i < resultList.Count; i++)
                            {
                                res2[i] = resultList[i].ToString();
                            }

                            using (StreamWriter sw = new StreamWriter(path, true))
                            {
                                foreach (string s in res2)
                                {
                                    if (s != "" && s != null)
                                    {
                                        sw.WriteLine(s);
                                    }
                                }
                            }

                            isSaved = true;
                            Console.WriteLine("Сохранение прошло успешно.");
                        }
                        catch
                        {
                            Console.WriteLine("Произошла ошибка при сохранении. Введите новый путь к файлу: ");
                            path = Console.ReadLine() ?? "";
                        }
                    }
                    else
                    {
                        Console.WriteLine("Файла по введённому пути не существует. Введите новый путь файла: ");
                        path = Console.ReadLine() ?? "";
                    }
                }
                break;
        }
    }

}