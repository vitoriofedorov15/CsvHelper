﻿namespace ClassLibrary;

/// <summary>
/// Класс для обработки CSV-данных.
/// </summary>
public class CsvProcessing
{
    /// <summary>
    /// Метод считывает CSV-данные и преобразует их в список объектов Kindergarten.
    /// </summary>
    /// <param name="data">Массив строк с CSV-данными.</param>
    /// <returns>Список объектов Kindergarten.</returns>
    public static List<Kindergarten> Read(string[] data)
    {
        // Создаем список для хранения строк CSV-данных.
        List<string[]> csvData = new List<string[]>();
        
        // Исключаем строку с заголовками из обработки.
        data = data[1..];

        // Обрабатываем каждую строку CSV-данных.
        for (int index = 0; index < data.Length; index++)
        {
            // Заменяем разделители внутри кавычек для корректного разделения строк.
            data[index] = data[index].Replace("\";\"", "*");
            data[index] = data[index].Replace("\";", "");
            data[index] = data[index].Replace(";\"", "*");

            // Проверяем, что в строке присутствует нужное количество разделителей.
            if ((data[index].Count(c => c == '*') != 14))
            {
                throw new Exception("Некорректная структура файла.");
            }

            // Разделяем строку на массив по разделителям и добавляем в список csvData.
            csvData.Add(data[index].Split("*"));
        }

        // Создаем список объектов Kindergarten и заполняем его данными из csvData.
        List<Kindergarten> kindergartens = new List<Kindergarten>();
        foreach (string[] x in csvData)
        {
            kindergartens.Add(new Kindergarten(x[0], x[1], x[2], x[3], x[4],
                x[5], x[6], x[7], x[8], x[9], x[10], 
                x[11], x[12], x[13], x[14].Replace(";", "")));
        }

        // Возвращаем список объектов Kindergarten.
        return kindergartens;
    }
}