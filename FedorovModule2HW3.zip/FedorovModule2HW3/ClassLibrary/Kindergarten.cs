namespace ClassLibrary;

public class Kindergarten
{
    private string _id, _name, _okrug, _rayon, _form_of_incorporation, 
        _submission, _x, _y, _globalId, _tip_uchrezhdenia, _vid_uchrezhdenia;
    private Address _address;
        
    public string Id
    {
        get =>_id;
        set => _id = value; 
    }
    public string Name {
        get => _name;
        set => _name = value; 
    }
    public string Okrug
    {
        get => _okrug;
        set => _okrug = value;
    }
    public string Rayon { 
        get => _rayon;
        set => _rayon = value;}
    public string FormOfIncorporation {
        get => _form_of_incorporation;
        set => _form_of_incorporation = value; 
    }
    public string Submission { 
        get => _submission;
        set => _submission = value;  
    }
    public string X { 
        get => _x;
        set => _x = value; 
    }
    public string Y { 
        get => _y;
        set => _y = value;
    }
    public string GlobalId { 
        get => _globalId;
        set => _globalId = value;
    }
    public string TipUchrezhdeniya
    {
        get => _tip_uchrezhdenia;
        set => _tip_uchrezhdenia = value;  
    }
    public string VidUchrezhdenia 
    { 
        get => _vid_uchrezhdenia;
        set => _vid_uchrezhdenia = value; 
    }

    public string Address => _address.AddressLocation; 
    public string Phone =>_address.Phone; 
    public string Website => _address.Website; 
    public string Email => _address.Email; 
    


    public Kindergarten(string id, string name, string address, string okrug, string rayon, string formOfIncorporation, 
        string submission, string tip_uchrezhdeniya, string vid_uchrezhdeniya, string phone, string website,
        string email, string x, string y, string globalId)
    {
        Id = id;
        Name = name;
        Okrug = okrug;
        Rayon = rayon;
        FormOfIncorporation = formOfIncorporation;
        Submission = submission;
        TipUchrezhdeniya = tip_uchrezhdeniya;
        VidUchrezhdenia = vid_uchrezhdeniya;
        X = x;
        Y = y;
        GlobalId = globalId;
        _address = new Address(address, phone, email, website);
    }

    public Kindergarten()
    {
        Id = "";
        Name = "";
        Okrug = "";
        Rayon = "";
        FormOfIncorporation = "";
        Submission = "";
        TipUchrezhdeniya = "";
        VidUchrezhdenia = "";
        X = "";
        Y = "";
        GlobalId = "";
        _address = new Address();
    }
    public override string ToString()
    {
        return $"{Id};\"{Name}\";\"{Address}\";\"{Okrug}\";\"{Rayon}\";\"{FormOfIncorporation}\";\"{Submission}\";\"{TipUchrezhdeniya}\";" +
               $"\"{VidUchrezhdenia}\";\"{Phone}\";\"{Website}\";\"{Email}\";\"{X}\";\"{Y}\";\"{GlobalId}\";";
    }
    /// <summary>
    /// Создаёт строку с данными о детском саде в табличном виде
    /// </summary>
    /// <returns>Строка с данными, разделёнными вертикальной чертой</returns>
    public string TableOutput()
    {
        return $"{Id} | {Name} | {Address} | {Okrug} | {Rayon} | {FormOfIncorporation} | {Submission} | {TipUchrezhdeniya} | " +
               $"{VidUchrezhdenia} | {Phone} | {Website} | {Email} | {X} | {Y} | {GlobalId}";
    }
}