﻿using System;
using static ClassLibrary.Methods;
namespace ClassLibrary;

public class Program
{
    public static void Main()
    {
        try
        {
            // Инициализация переменных и объектов.
            ConsoleKey endkey = ConsoleKey.Enter;
            string path;
            List<Kindergarten> kindergartens;
            string[] data;
            int userCommand;

            // Основной цикл программы.
            while (endkey != ConsoleKey.Tab)
            {
                // Чтение пути к файлу и данных из файла.
                StartingReadPath(out path, out data);

                // Проверка структуры данных и создание списка детских садов.
                CheckDataStructure(ref data, out kindergartens);

                // Вывод меню на консоль.
                PrintMenu();
                
                // Чтение команды пользователя.
                CheckInputCommand(out userCommand);

                // Цикл обработки команд пользователя.
                while (userCommand != 5)
                {
                    List<Kindergarten> resultList = new List<Kindergarten>();

                    // Обработка команды пользователя.
                    switch (userCommand)
                    {
                        case 1:
                            // Вывод N первых/последних записей на консоль.
                            CommandPrintNLines(ref kindergartens);
                            break;
                        case 2:
                            // Сортировка данных.
                            CommandSort(ref resultList, ref kindergartens);
                            break;
                        case 3:
                            // Фильтрация по значению vid_uchrezhdenia.
                            CommandFilter("vid_uchrezhdenia", ref kindergartens, ref resultList);
                            break;

                        case 4:
                            // Фильтрация по значению form_of_incorporation.
                            CommandFilter("form_of_incorporation", ref kindergartens, ref resultList);
                            break;

                        default:
                            Console.WriteLine("Введённой команды не существует, повторите ввод.");
                            break;
                    }

                    // Повторение программы, учитывая новую команду, введённую пользователем.
                    ProgramRepeating(ref userCommand, ref resultList);
                }

                // Завершение программы или продолжение работы.
                ProgramEnding(ref endkey);
            }
        }
        catch (Exception ex)
        {
            // Обработка и вывод ошибок.
            Console.WriteLine($"Произошла ошибка. {ex.Message} Программа будет завершена.");
        }
    }
}
